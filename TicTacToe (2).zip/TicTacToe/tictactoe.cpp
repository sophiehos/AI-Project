#include <iostream>
#include <iomanip>
#include <vector>
#include <ctime>
#include <cstdlib>

using namespace std;

enum cases
{
    TIE = -1,
    Na = 0,
    AI = 1,
    HUMAN = 2
};

int wins[8][3] = {
    {0, 1, 2},
    {3, 4, 5},
    {6, 7, 8},
    {0, 3, 6},
    {1, 4, 7},
    {2, 5, 8},
    {0, 4, 8},
    {6, 4, 2}};

struct Move
{
    int pos;
    int score;

    Move(){};
    Move(int score);
};

Move::Move(int score)
{
    this->score = score;
}

int check_win(int (&board)[9])
{
    for (int i = 0; i < 8; i++)
    {
        if (board[wins[i][0]] == HUMAN && board[wins[i][1]] == HUMAN && board[wins[i][2]] == HUMAN)
        {
            return HUMAN;
        }
        else if (board[wins[i][0]] == AI && board[wins[i][1]] == AI && board[wins[i][2]] == AI)
        {
            return AI;
        }
    }

    for (int i = 0; i < 9; i++)
    {
        if (board[i] == Na)
            return Na;
    }

    return TIE;
}

void print(int (&board)[9], int user_side, bool first_round)
{
    for (int i = 0; i < 9; i++)
    {
        if (i % 3 == 0)
            cout << endl
                 << "-------------" << endl
                 << setw(2) << left << "|";
        if (board[i] == AI)
            cout << (user_side == 1 ? "o" : "x") << setw(2) << right << "|" << setw(2) << right;
        else if (board[i] == HUMAN)
            cout << (user_side == 1 ? "x" : "o") << setw(2) << right << "|" << setw(2) << right;
        else
            cout << (first_round ? to_string(i + 1) : " ") << setw(2) << right << "|" << setw(2) << right;
    }
    cout << endl
         << "-------------" << endl;
}

int best_move(std::vector<Move> &moves, int player)
{
    int best = 0;
    int bestScore = player == HUMAN ? 1000 : -1000;
    for (int i = 0; i < moves.size(); i++)
    {
        if (moves[i].score > bestScore == (AI ? true : false))
        {
            best = i;
            bestScore = moves[i].score;
        }
    }

    return best;
}

Move alpha_beta(int (&board)[9], int player, int alpha, int beta)
{
    int win = check_win(board);
    if (win == HUMAN)
        return Move(-10);
    else if (win == AI)
        return Move(10);
    else if (win == TIE)
        return Move(0);

    std::vector<Move> moves;

    for (int i = 0; i < 9; i++)
    {
        if (board[i] == Na)
        {
            Move move;
            move.pos = i;

            board[i] = player;

            if (player == AI)
            {
                move.score = alpha_beta(board, HUMAN, alpha, beta).score;
            }
            else
            {
                move.score = alpha_beta(board, AI, alpha, beta).score;
            }

            moves.push_back(move);
            board[i] = Na;

            // Alpha-Beta pruning
            if (player == AI)
            {
                if (move.score > alpha)
                {
                    alpha = move.score;
                }
            }
            else
            {
                if (move.score < beta)
                {
                    beta = move.score;
                }
            }

            if (alpha >= beta)
            {
                break; // Prune the branch
            }
        }
    }

    int bestMove = best_move(moves, player);

    return moves[bestMove];
}

int get_user_side()
{
    int side;
    cout << "Choose your side (1 for 'X', 2 for 'O'): ";
    cin >> side;

    while (side != 1 && side != 2)
    {
        cout << "Invalid input. Please choose either 1 for 'X' or 2 for 'O': ";
        cin >> side;
    }

    return side;
}

void game()
{
    int pos;
    int user_side = get_user_side();
    int player = (user_side == 1) ? HUMAN : AI;

    int board[9] = {Na};
    bool first_round = true;

    while (true)
    {
        print(board, user_side, first_round);
        first_round = false;

        int win = check_win(board);
        if (win != Na)
        {
            if (win == TIE)
                cout << "It was a tie\n";
            else if (win == HUMAN)
                cout << "The user wins!\n";
            else if (win == AI)
                cout << "The AI wins!\n";
            break;
        }

        if (player == HUMAN)
        {
            cout << "\nPlayer's turn\nInput a number: ";
            cin >> pos;

            if (pos < 10 && pos > 0)
            {
                if (board[pos - 1] == AI || board[pos - 1] == HUMAN)
                    cout << "Position already taken\n";
                else
                {
                    board[pos - 1] = HUMAN;
                    player = AI;
                }
            }
            else
            {
                cout << "Invalid input, try again..\n";
            }
        }
        else
        {
            cout << "\nAI's turn\n";

            int empty_cells = 0;
            for (int i = 0; i < 9; i++)
            {
                if (board[i] == Na)
                    empty_cells++;
            }

            if (empty_cells == 9) // AI's first move
            {
                int random_pos = rand() % 9;
                board[random_pos] = AI;
            }
            else // AI's subsequent moves
            {
                Move move = alpha_beta(board, AI, -1000, 1000); // Call alpha_beta with initial alpha and beta values
                board[move.pos] = AI;
            }

            player = HUMAN;
        }
    }
}

int main()
{
    srand(static_cast<unsigned int>(time(0))); // Initialize random seed
    game();
    return 0;
}
